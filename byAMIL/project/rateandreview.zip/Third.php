<?php

$id=$_GET['bid'];
if($conn=mysqli_connect("localhost","root","","phonegallery")){
$sql1="SELECT * from  phones
where brandID='$id'";
if($ress=mysqli_query($conn,$sql1)){
$phones=mysqli_fetch_all($ress);
}
    $sql1="SELECT * from   specifications
where  phoneID='$id' ";

    if($res=mysqli_query($conn,$sql1)){
        $recent=mysqli_fetch_all($res);
    }
    if($conn=mysqli_connect("localhost","root","","phonegallery")){
    $rate='';
$text= '';
if(isset($_POST['submit'])){
    if(isset($_POST['Rate'])){
    	$rate= $_POST['Rate'];
    }
    if(isset($_POST['text']) and !empty($_POST['text'])){
    	 $text=$_POST['text'];
    }
       
      
$sql1="INSERT INTO ratesnreviews
(rating,review,userID,phoneID)
values
($rate,'$text',2,$id)";
if(mysqli_query($conn,$sql1)){
	echo " inserted";

}
}
}
       
    }

?>

<!DOCTYPE html>
<html>
<head>
	<title>third page </title>
	
	<link rel="stylesheet" type="text/css" href="library/fontAwesome/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="library/bootstrap-4.3.1-dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="designe.css">
		

</head>
<body>
	<div class="head">
		<div class="first">
			 <nav class="navbar navbar-expand-sm bg-light  fa-border justify-content-right" >

            <span class="fa fa-pull-left ">
                <i class="fa fa-facebook fa-border fa-2x"> </i>
                <i class="fa fa-youtube fa-border fa-2x"> </i>
                <i class="fa fa-google fa-border fa-2x"> </i>
                <a href="First.php" class="fa fa-home  fa-border fa-2x"></a></span>
                 <form  class="fa fa-pull-right   ">
                <i class="fa fa-user  fa-pull-right fa-border fa-2x "></i>
                <button class="fa-pull-right fa-border ">Search <i class="fa fa-border fa-search"></i></button>
               <biv class="fa fa-border search"> <input type="text" id="search"  name="search" ><div></form>

        </nav>
		</div>
		<div class="second">
			<h1>PHONE GALLERY</h1>
		</div>
		
			
		<div class="third">
			<div class="thirdF">
				
				<div class="thirdFirst">
                    				<ul class="list-group list-group-horizontal">
  <a href="third.php"><li class="list-group-item"><img src="2.jpeg" width="60px" height="75px"></li></a>
 <a href="third.php"><li class="list-group-item"><img src="2.jpeg" width="60px" height="75px"></li></a>
 <a href="third.php"><li class="list-group-item"><img src="2.jpeg" width="60px" height="75px"></li></a>
</ul>
				<ul class="list-group list-group-horizontal">
    <li class="list-group-item"><a href="second.php">First item<</a></li>
    <li class="list-group-item">Second item</li>
    <li class="list-group-item">Third item</li>
</ul>
				<ul class="list-group list-group-horizontal">
    <li class="list-group-item"><a href="second.php">First item<</a></li>
    <li class="list-group-item">Second item</li>
    <li class="list-group-item">Third item</li>
</ul>
				</div>

				<div class="thirdSecond">
                    <ul class="list-group list-group-horizontal">
                        <?php
                        $index=0;

                        foreach ( $recent as $row){
                            if($index%5==0){
                                echo "</ul><ul class=\"list-group list-group-horizontal\">";
                            }

                            echo"<a href=\"Third.php?bid=".$row[0]."\"><li class=\"list-group-item border-0\">
                        <div class=\"phone-img\">
                        <img src=\"".$row[2]."\" alt=\"".$row[1]."\">
                        </div>
                        <div class=\"Phone-name\">
                        <span>".$row[1]."</span>
                        </div>
                        </li></a>";
                            $index++;}
                        ?>

                    </ul>

				</div>
			
			</div>

			<div class="thirdS">
				<div class="thirdSFirst">				
					 Mobile Types
				</div>
				<div class="thirdSSecond">
					<?php 
						include "slider.php";
					 ?>

				</div>
				<div class="thirdSThird">
					<table class="table table-striped">
						<tr>
							<td> LAUNCH:</td>
							<td> </td>
						</tr>
						<tr>
							<td>BODY: </td>
							<td> </td>
						</tr>
						<tr>
							<td>DISPLAY: </td>
							<td> </td>
						</tr>
						<tr>
							<td>PLATFORM:</td>
							<td> </td>
						</tr>
						<tr>
							<td>MEMORY:</td>
							<td> </td>
						</tr>
						<tr>
							<td>CAMERA: </td>
							<td> </td>
						
						</tr>
						<tr>
							<td>SOUND:</td>
							<td></td>
						</tr>
						<tr>
							<td>COMMUNICATION: </td>
							<td> </td>
						</tr>
						<tr>
							<td>SENSORS: </td>
							<td> </td>
						</tr>
						<tr>
							<td>BATTERY: </td>
							<td> </td>
						</tr>

					</table>
					
				</div>




				<div class="thirdSFourth">

                    <div class="rating">

                      <form method="POST" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                        <h3>Rate us </h3>
                        <input type="radio" name="Rate" value="1">
                        <input type="radio" name="Rate" value="2">
                        <input type="radio" name="Rate" value="3">
                        <input type="radio" name="Rate" value="4">
                        <input type="radio" name="Rate" value="5">
                        <h3>Review us</h3>
                       <textarea type="text" name="text"></textarea>
                       <br>
                       <input type="submit" name="submit" value="send">
                    

                        </form>









                    </div>
					
				</div>				
			</div>
			</div>
			
			<div class="last">&copy; phone gallery.com</div>
		
		
	</div>
		
	
	

</body>

</html>
