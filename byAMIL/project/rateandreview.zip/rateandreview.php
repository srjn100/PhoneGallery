<?php
$rate='';
$text= '';
if(isset($_POST['submit'])){
    if(isset($_POST['text'])and !empty($_POST['text'])){
        $text=$_POST['text'];
        
    }
    else{
        echo "error";
    }
    if(isset($_POST['Rate'])){
       $rate= $_POST['Rate'];
       
    }
     else{
        echo "error2";
    }
    echo $text;
    echo $rate;

    if($conn=mysqli_connect("localhost","root","","phonegallery")){

$sql="INSERT into  ratesnreviews
(rating,review,userID,phoneID)
values
($rate,'$text',2,10)";
if(mysqli_query($conn,$sql)){
    echo " inserted";


}
}
}

?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>


</body>
</html>
  